
✅ ІНСТРУКЦІЯ:

1. Встанови Python (якщо ще не встановлено): https://www.python.org/downloads/
2. Встанови потрібні бібліотеки. Відкрий термінал і введи:
   pip install requests python-telegram-bot beautifulsoup4

3. Відкрий файл bot_checker.py в будь-якому редакторі (наприклад, VS Code або Notepad++)
4. Замініть рядок:
   TELEGRAM_TOKEN = "YOUR_TELEGRAM_BOT_TOKEN_HERE"
   👉 встав сюди свій новий токен з BotFather

5. Запусти файл:
   python bot_checker.py

6. Все! Бот перевіряє кожну хвилину і напише тобі в Telegram, коли з'явиться місце на 31 травня у Чернігові.
